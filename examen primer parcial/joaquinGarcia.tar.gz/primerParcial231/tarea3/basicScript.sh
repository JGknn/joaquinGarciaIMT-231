#!/bin/bash

echo "Ingrese su nombre, porfavor: "
read nombre
echo "Hola, $nombre"

mkdir ubicaciones
cd ubicaciones
touch ubicacion.txt
pwd >> ubicacion.txt
cd ..
touch fechaTarea3.txt
date >> fechaTarea3.txt

tree -p

echo "Este script ha finalizado!"
